import React from "react";
import "./styles/footer.css";

function Footer() {
  return (
    <footer>
      <div>Brand</div>
    </footer>
  );
}

export default Footer;
